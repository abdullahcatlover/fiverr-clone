import React from 'react'
import './messages.scss'
import { messages } from '../../data'
import { Link } from 'react-router-dom'

const Messages = () => {

 


/*   const message = 'lorem, Nisi nobis adipisci
 tempore sint quasi totam ab eos, 
 quidem reprehenderit 
 ut. dolor sit amet consectetur 
 adipisicing elit.' */

  return (
    <div className='messages'>
      <div className="container">
        <div className="title">
          <h1>Messages</h1>
        </div>
        <table>
          <tr>
            <th>Buyer</th>
            <th>Last Message</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
          {
            messages.map((info) => {
              const activeMessageIds = [1, 2];
              const isActive = activeMessageIds.includes(info.id)
              const excludedUserIds = [3, 4, 5, 6, 7];
              const isExcludedUser = excludedUserIds.includes(info.id);
              return (
                <tr key={info.id} className={isActive ? "active" : ""}>
                  <td>{info.name}</td>
                  <td><Link to='/message/123' className='link'>{info.message.substring(0, 100)}...</Link></td>
                  <td>{info.lastTime}</td>
                  <td>{isExcludedUser ? null : <button>Mark as Read</button>}</td>
                </tr>
              )
            })
          }
        </table>
      </div>
    </div>
  )
}

export default Messages




/* 
  <tr>
            <td>
               John Doe
            </td>
            <td>
              {message}
            </td>
            <td>1 day ago</td>
            <td>
              <button>Mark as Read</button>
            </td>
          </tr>
          <tr>
            <td>
               John Doe
            </td>
            <td>
              {message}
            </td>
            <td>1 day ago</td>
            <td>
              <button>Mark as Read</button>
            </td>
          </tr>
          <tr>
            <td>
               John Doe
            </td>
            <td>
              {message}
            </td>
            <td>1 day ago</td>
            <td>
              <button>Mark as Read</button>
            </td>
          </tr>
          <tr>
            <td>
               John Doe
            </td>
            <td>
              {message}
            </td>
            <td>1 day ago</td>
            <td>
              <button>Mark as Read</button>
            </td>
          </tr>
          <tr>
            <td>
               John Doe
            </td>
            <td>
              {message}
            </td>
            <td>1 day ago</td>
            <td>
              <button>Mark as Read</button>
            </td>
          </tr>
          <tr>
            <td>
               John Doe
            </td>
            <td>
              {message}
            </td>
            <td>1 day ago</td>
            <td>
              <button>Mark as Read</button>
            </td>
          </tr>
          <tr>
            <td>
               John Doe
            </td>
            <td>
              {message}
            </td>
            <td>1 day ago</td>
            <td>
              <button>Mark as Read</button>
            </td>
          </tr>  */