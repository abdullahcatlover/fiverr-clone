import React from 'react'
import './register.scss'

const Register = () => {
  return (
    <div>
       register
    </div>
  )
}

export default Register
