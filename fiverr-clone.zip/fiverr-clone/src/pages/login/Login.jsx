import React from 'react'
import './login.scss'

const Login = () => {
  return (
    <div>
      Login
Login
    </div>
  )
}

export default Login
