import React from 'react'
import './message.scss'
import { Link } from 'react-router-dom'
import { message } from '../../data'

const Message = () => {
  return (
    <div className='message'>
      <div className="container">
        <span className="breadcrumbs">
          <Link to="/messages">MESSAGES</Link> > JOHN DOE
        </span>
        <div className="messages">

          {
            message.map((chat) => {
              const ownerMessageIds = [2, 4, 5, 7, 9]
              const ownerMessage = ownerMessageIds.includes(chat.id);
              const itemClass = ownerMessage ? "item owner" : "item"
              return (
                <div className={itemClass} key={chat.id}>
                  <img src={chat.img} alt="" />
                  <p>{chat.chat}</p>
                </div>
              )
            })
          }
        </div>
        <hr />
        <div className="write">
          <textarea name="" placeholder='write a message' id="" cols="30" rows="10"></textarea>
          <button>Send</button>
        </div>

      </div>
    </div>
  )
}

export default Message
